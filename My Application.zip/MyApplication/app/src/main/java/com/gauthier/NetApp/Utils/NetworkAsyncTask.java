package com.gauthier.NetApp.Utils;

import android.os.AsyncTask;
import android.util.Log;

import java.lang.ref.WeakReference;

/**
 * Created by Alexandre GAUTHIER on 2020/10/26.
 */
public class NetworkAsyncTask extends AsyncTask<String, Void , String> {

    public interface Listeners {
        void onPreExecute();
        void doInBackground();
        void onPostExecute(String success);


    }

    private final WeakReference<Listeners> callback;

    //constructor
    public NetworkAsyncTask(Listeners callback) {
        this.callback = new WeakReference<>(callback);
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        this.callback.get().onPreExecute();
        Log.e("TAG","AsyncTask is started");
    }

    protected void onPostExectute(String success) {
        super.onPostExecute(success);
        this.callback.get().onPostExecute(success);
        Log.e("TAG" , "AsyncTask is finished");
    }

    @Override
    protected String doInBackground(String... url) {
        this.callback.get().doInBackground();
        Log.e("TAG" , "AsyncTask is doing some big work");
        return MyHttpURLConnection.startHttpRequest(url[0]);
    }
}
