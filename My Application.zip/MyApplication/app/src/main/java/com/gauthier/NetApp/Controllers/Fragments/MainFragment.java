package com.gauthier.NetApp.Controllers.Fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.gauthier.NetApp.Models.GithubUser;
import com.gauthier.NetApp.Models.GithubUserInfo;
import com.gauthier.NetApp.R;
import com.gauthier.NetApp.Utils.GithubStreams;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableObserver;


/**
 * A simple {@link Fragment} subclass.
 */
public class MainFragment extends Fragment {

    // FOR DESIGN
    @BindView(R.id.fragment_main_textview)
    TextView textView;

    // FOR DATA
// 4 - Declare Subscription
    private Disposable disposable;

    public MainFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.disposeWhenDestroy();
    }

// -----------------
// ACTIONS
// -----------------

    @OnClick(R.id.fragment_main_button)
    public void submit(View view) {
        // this.executeHttpRequestWithRetrofit();
        // this.streamshowString();
        // 2 - Call the stream
        this.executeSecondHttpRequestWithRetrofit();
    }


//----------------
// HTTP (RxJAVA)
//----------------

    // 1 - execute our stream
    private void executeHttpRequestWithRetrofit() {
        // 1.1 - Update UI
        this.updateUIWhenStartingHTTPRequest();

        // 1.2 - Execute the stream subscribing to Observable defind inside GithubStream
        this.disposable = GithubStreams.streamFetchUserFollowing("JakeWharton").subscribeWith(new DisposableObserver<List<GithubUser>>() {
            @Override
            public void onNext(List<GithubUser> users) {
                Log.e("TAG", "On Next");
                // 1.3 - Update UI with list of users
                updateUIWithListOfUsers(users);
            }

            @Override
            public void onError(Throwable e) {
                Log.e("TAG", "On Error" + Log.getStackTraceString(e));
            }

            @Override
            public void onComplete() {
                Log.e("TAG", "on Complete !!");
            }
        });
    }

    private void executeSecondHttpRequestWithRetrofit() {
        this.updateUIWhenStartingHTTPRequest();
        this.disposable = GithubStreams.streamFetchUserFollowingAndFetchFirstUserInfos("JakeWharton").subscribeWith(new DisposableObserver<GithubUserInfo>() {
            @Override
            public void onNext(GithubUserInfo users) {
                Log.e("TAG", "On Next");
                updateUIWithUserInfo(users);
            }


            @Override
            public void onError(Throwable e) {
                Log.e("TAG", "OnError" + Log.getStackTraceString(e));

            }

            @Override
            public void onComplete() {
                Log.e("TAG", "On Complete !!");
            }
        });
    }

    private void disposeWhenDestroy() {
        if (this.disposable != null && !this.disposable.isDisposed()) {
            this.disposable.dispose();
        }
    }


//-----------------
// UPDATE UI
//-----------------

    private void updateUIWhenStartingHTTPRequest() {
        this.textView.setText("Downloading...");
    }

    private void updateUIWithListOfUsers(List<GithubUser> users) {
        StringBuilder stringBuilder = new StringBuilder();
        for (GithubUser user : users) {
            stringBuilder.append(" - " + user.getLogin() + "\n");
        }
        updateUIWhenStopingHTTPRequest(stringBuilder.toString());
    }

    private void updateUIWhenStopingHTTPRequest(String response) {
        this.textView.setText(response);
    }

    private void updateUIWithUserInfo(GithubUserInfo userInfo) {
        updateUIWhenStopingHTTPRequest("The first following of jake Wharton is " + userInfo.getName()
                + " with " + userInfo.getFollowers() + " followers.");
    }
}