package com.gauthier.NetApp.Utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Alexandre GAUTHIER on 2020/10/26.
 */
public class MyHttpURLConnection {

    public static String startHttpRequest(String urlString) {
        StringBuilder stringBuilder = new StringBuilder();

        try {
            // 1 - declare a URL Connection
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // 2 - open inputStream to connection
            connection.connect();
            InputStream inputStream = connection.getInputStream();

            // 3 - Download and decode the string response
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        } catch (Exception e) {
        }

        return stringBuilder.toString();
    }
}

