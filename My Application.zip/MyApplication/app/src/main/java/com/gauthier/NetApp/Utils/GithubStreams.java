package com.gauthier.NetApp.Utils;

import com.gauthier.NetApp.Models.GithubUser;
import com.gauthier.NetApp.Models.GithubUserInfo;

import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by Alexandre GAUTHIER on 2020/10/29.
 */
public class GithubStreams {

    // 1 - Create a stream that will get user infos on Github API
    public static Observable<List<GithubUser>> streamFetchUserFollowing(String username) {
        GithubService githubService = GithubService.retrofit.create(GithubService.class);
        return githubService.getFollowing(username)
                .subscribeOn(Schedulers.io()) // permet d'exécuter l'observable dans un thread dédié(Schedulers.io) no nead of asynctask
                .observeOn(AndroidSchedulers.mainThread()) // permet de dire à ts les subscribers d'écouter le flux de données de l'observale sur le thread ppl (ce qui permet de modifier les élements de UI depuis la méthode onNext()
                .timeout(10, TimeUnit.SECONDS); // si l'émission n'est pas effectué ici en moins de 10 secondes alors error Timeout envoyée aux subscribers via onError()
    }

    public static Observable<GithubUserInfo> streamFetchUserInfos(String username){
        GithubService gitHubService = GithubService.retrofit.create(GithubService.class);
        return gitHubService.getUserInfos(username)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .timeout(10, TimeUnit.SECONDS);
    }

    // 2 - Create a stream that will :
    //     A - Fetch all users followed by "username"
    //     B - Return the first user of the list
    //     C - Fetch details of the first user
    public static Observable<GithubUserInfo> streamFetchUserFollowingAndFetchFirstUserInfos(String username) {
        return streamFetchUserFollowing(username) // A.
            .map(new Function<List<GithubUser>, GithubUser>() { // on récupère la list de githubUser
                @Override
                public GithubUser apply(List<GithubUser> users) throws Exception {
                    return users.get(0); // B.
                }
            })
            .flatMap(new Function<GithubUser, Observable<GithubUserInfo>>() {
                @Override
                public Observable<GithubUserInfo> apply(GithubUser user) throws Exception {
            // C.
                    return streamFetchUserInfos(user.getLogin());
                }
        });
    }
}
